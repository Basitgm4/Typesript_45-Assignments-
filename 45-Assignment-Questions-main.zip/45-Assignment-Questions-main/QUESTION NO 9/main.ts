// Q9)Favorite Number: Store your favorite number in a variable. Then, using that variable, 
// create a message that reveals your favorite number. Print that message.
//Answer:
let favoriteNumber: number = 7
console.log(`My Favorite Number is ${favoriteNumber}`);
