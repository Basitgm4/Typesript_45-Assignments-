// Q7)Number Eight: Write addition, subtraction, multiplication, and division operations that each result in the number 
// 8. Be sure to enclose your operations in print statements to see the results.
//Answer:
console.log(5 + 3); // Addition
console.log(10 - 2); // Subtraction
console.log(4 * 2); // Multiplication
console.log(16 / 2); // Division