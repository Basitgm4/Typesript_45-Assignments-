// Q12)Greetings: Start with the array you used in Exercise 11, but instead of just printing each person’s name, 
// print a message to them. The text of each message should be the same, 
// but each message should be personalized with the person’s name.
//Answer:
let names: string[]= ["rohan","Farhan","Ali"];
for (let name of names){
    console.log(`Hellow ${name} would you like to learn some python today?`)
}
