// Q8)You should create four lines that look like this:
// console.log(5 + 3)
// Your output should simply be four lines with the number 8 appearing once on each line.
//Answer:
// console.log(5 + 3); // Addition
// console.log(10 - 2); // Subtraction
// console.log(4 * 2); // Multiplication
// console.log(16 / 2); // Division
console.log(5 + 3); 
console.log(5 + 3); 
console.log(5 + 3); 
console.log(5 + 3); 