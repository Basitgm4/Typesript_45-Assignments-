// Q10)Adding Comments: Choose two of the programs you’ve written, and add at least one comment to each.
//  If you don’t have anything specific to write because your programs are too simple at this point, 
//  just add your name and the current date at the top of each program file. 
//  Then write one sentence describing what the program does.
//Answer:
// Rohan Mirza, 03-14-2024
//This program print a personal message.
let myname: string = "Rohan Mirza";
console.log(`Hello ${myname}, would you like to learn some python? `);