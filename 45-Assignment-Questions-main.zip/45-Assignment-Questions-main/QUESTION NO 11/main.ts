// Q11)Names: Store the names of a few of your friends in a array called names.
//  Print each person’s name by accessing each element in the list, one at a time.
//Answer:
let names: string[] = ["Rohan", "Farhan", "Ali"];
for (let i = 0; i < names.length; i++) {
    console.log(names[i]);
}