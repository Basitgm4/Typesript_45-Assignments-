// Q5) Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. 
// Then compose your message and store it in a new variable called message. Print your message.
//Answer:
let famous_person: string= "William Shakespeare"
let message: string= `${famous_person} "All the world’s a stage, and all the men and women merely players."`;
console.log(message)