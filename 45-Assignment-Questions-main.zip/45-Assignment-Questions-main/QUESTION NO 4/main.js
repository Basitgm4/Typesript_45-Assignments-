"use strict";
// Q4) amous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. 
// Your output should look something like the following, including the quotation marks:
// Answer:
console.log(`William Shakespeare, "All the world’s a stage, and all the men and women merely players."`);
