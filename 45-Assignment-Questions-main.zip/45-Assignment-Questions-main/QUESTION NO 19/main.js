"use strict";
// Q19)Dinner Guests: Working with one of the programs from Exercises 14 through 18, 
// print a message indicating the number of people you are inviting to dinner.
//Answer:
let guests = ["Farhan", "Rohan", "Rehan", "Nafay", "Zoha"];
console.log(`I am inviting ${guests.length} people to dinner.`);
